const express = require('express');
const path = require('path');
const oracledb = require('oracledb');

const app = express();

// Database connection details
const dbConfig = {
  user: "user",
  password: "12345",
  connectString: "127.0.0.1:8080/XE", // Correct the port to 1521
};

// Set the view engine to EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'public')); // Ensure views are in the 'public' folder

// Middleware to parse JSON data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (CSS, JS) from the public folder
app.use(express.static(path.join(__dirname, 'public')));

// Route to render the login page
app.get('/', (req, res) => {
  res.render('login'); // Ensure 'login.ejs' exists in the 'public' folder
});

// Register User (Signup Route)
app.post("/signup", async (req, res) => {
  const { username, password } = req.body;

  try {
    const connection = await oracledb.getConnection(dbConfig);
    console.log('Connected to Oracle Database');

    // Check if the username already exists
    const result = await connection.execute(
      `SELECT * FROM users WHERE username = :username`,
      [username]
    );

    if (result.rows.length > 0) {
      return res.json({ success: false, message: "User already exists." });
    }

    // Insert the new user with dynamic values
    await connection.execute(
      `INSERT INTO users (username, password) VALUES (:username, :password)`,
      [username, password], // Use dynamic values from the form input
      { autoCommit: true }
    );

    res.json({ success: true, message: "Signup successful!" });
  } catch (error) {
    console.error("Signup Error:", error);
    res.status(500).json({ success: false, message: "Internal Server Error." });
  }
});

// Login User (Login Route)
app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const connection = await oracledb.getConnection(dbConfig);
    console.log('Connected to Oracle Database');

    // Check if the username exists
    const result = await connection.execute(
      `SELECT username, password FROM users WHERE username = :username`,
      [username]
    );

    if (result.rows.length === 0) {
      return res.json({ success: false, message: "Username not found." });
    }

    const [dbUsername, dbPassword] = result.rows[0];

    // Compare the password
    if (dbPassword !== password) {
      return res.json({ success: false, message: "Incorrect password." });
    }

    res.json({ success: true, message: "Login successful!" });
  } catch (error) {
    console.error("Login Error:", error);
    res.status(500).json({ success: false, message: "Internal Server Error." });
  }
});

// Start the server
const port = 5000;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
