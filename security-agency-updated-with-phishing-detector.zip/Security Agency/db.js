const oracledb = require('oracledb');

async function connectToDatabase() {
  let connection;

  try {
    // Use your Oracle database configuration
    connection = await oracledb.getConnection({
      user: 'user',
      password: '12345',
      connectString: 'localhost:8080/XE' // Example: 'localhost/orclpdb1'
    });

    console.log('Connected to Oracle Database!');

    // Execute a simple query
    const result = await connection.execute('SELECT * FROM users');
    console.log(result.rows); // Log the query result
  } catch (err) {
    console.error('Error connecting to Oracle Database:', err);
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log('Connection closed.');
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
}

connectToDatabase();
