from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl, ValidationError
from typing import List, Dict, Any
import re, json, os
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score

APP_DIR = os.path.dirname(__file__)
MODEL_PATH = os.path.join(APP_DIR, "model.pkl")
STATS_PATH = os.path.join(APP_DIR, "stats.json")
DATASET_PATH = os.path.join(APP_DIR, "sample_dataset.csv")

app = FastAPI(title="Phishing URL Detector", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class UrlIn(BaseModel):
    url: str

def load_stats():
    if os.path.exists(STATS_PATH):
        with open(STATS_PATH, "r") as f:
            return json.load(f)
    return {"total": 0, "phishing": 0, "legit": 0}

def save_stats(stats):
    with open(STATS_PATH, "w") as f:
        json.dump(stats, f)

def suspicious_reasons(url: str) -> List[str]:
    reasons = []
    if len(url) > 75:
        reasons.append("Very long URL")
    if url.count("//") > 1:
        reasons.append("Multiple '//' sequences")
    if "@" in url:
        reasons.append("Contains '@' (obfuscation)")
    if "-" in url.split("://")[-1].split("/")[0]:
        reasons.append("Hyphen in domain")
    if re.search(r"\d+\.\d+\.\d+\.\d+", url):
        reasons.append("IP address used instead of domain")
    if re.search(r"(login|verify|update|secure|bank|free|bonus|urgent)", url, re.I):
        reasons.append("Contains suspicious keywords")
    if re.search(r"\.(zip|rar|icu|science|top|xyz)(/|$)", url, re.I):
        reasons.append("Unusual/suspect TLD")
    return reasons

# Simple text-model pipeline trained on small sample to satisfy 'trained model' requirement
# In real deployment, replace sample_dataset.csv with a proper dataset.
PIPE: Pipeline = None

def ensure_model():
    global PIPE
    if PIPE is not None:
        return PIPE
    # Train from sample dataset
    df = pd.read_csv(DATASET_PATH)
    X = df["url"].astype(str)
    y = df["label"].astype(int)
    PIPE = Pipeline([
        ("vec", CountVectorizer(ngram_range=(1,2), min_df=1, max_features=5000)),
        ("clf", LogisticRegression(max_iter=1000))
    ])
    PIPE.fit(X, y)
    return PIPE

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/stats")
def stats():
    s = load_stats()
    pct_phish = (s["phishing"]/s["total"]*100.0) if s["total"] else 0.0
    return {"total": s["total"], "phishing": s["phishing"], "legit": s["legit"], "phishing_pct": round(pct_phish, 2)}

@app.post("/predict")
def predict(inp: UrlIn):
    url = inp.url.strip()
    model = ensure_model()
    proba = float(model.predict_proba([url])[0][1])  # probability of class 1 == phishing
    label = 1 if proba >= 0.5 else 0
    reasons = suspicious_reasons(url)

    # Update stats
    s = load_stats()
    s["total"] += 1
    if label == 1:
        s["phishing"] += 1
    else:
        s["legit"] += 1
    save_stats(s)

    return {
        "url": url,
        "prediction": "phishing" if label == 1 else "safe",
        "probability": round(proba, 3),
        "reasons": reasons
    }
