# Backend (FastAPI)

## Run locally
```bash
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

### Endpoints
- `GET /health` → health check
- `GET /stats` → cumulative stats
- `POST /predict` → body: `{ "url": "http://..." }`

### Notes
- A lightweight Logistic Regression pipeline is trained at startup on `sample_dataset.csv` (placeholder). Replace it with a real dataset for better accuracy.
- The API returns an explainability `reasons` list based on URL heuristics (e.g., long length, IP in domain, suspicious TLD/keywords).
