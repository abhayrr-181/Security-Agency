# Frontend (React + Vite)

## Run locally
```bash
npm install
npm run dev
```
Set the API base URL by creating a `.env` file:
```
VITE_API_BASE=http://localhost:8000
```

## Build for deployment
```bash
npm run build
```
Deploy the `dist/` folder to Vercel/Netlify.
