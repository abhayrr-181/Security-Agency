import React, { useState, useEffect } from 'react'
import { predictUrl, fetchStats } from './api'

function Badge({status}){
  if(status === 'phishing') return <span className="badge danger">❌ Phishing</span>
  if(status === 'safe') return <span className="badge safe">✅ Safe</span>
  return null
}

function Progress({label, value, max=100}){
  return (
    <div className="progress">
      <div className="progress-bar" style={{width: `${(value/max)*100}%`}}></div>
      <div className="progress-label">{label}: {value}%</div>
    </div>
  )
}

export default function App(){
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [stats, setStats] = useState({total:0, phishing:0, legit:0, phishing_pct:0})

  const submit = async (e)=>{
    e.preventDefault()
    setError(null); setResult(null); setLoading(true)
    try{
      const data = await predictUrl(url)
      setResult(data)
      const s = await fetchStats()
      setStats(s)
    }catch(err){
      setError(err.message || 'Something went wrong')
    }finally{
      setLoading(false)
    }
  }

  useEffect(()=>{
    fetchStats().then(setStats).catch(()=>{})
  }, [])

  return (
    <div className="container">
      <h1>Phishing URL Detector</h1>
      <p className="subtitle">Enter a URL and we&apos;ll predict whether it looks suspicious using an ML model + heuristics.</p>

      <form onSubmit={submit} className="card">
        <input
          type="url"
          placeholder="https://example.com/login"
          value={url}
          onChange={(e)=>setUrl(e.target.value)}
          required
        />
        <button disabled={loading}>{loading ? 'Checking...' : 'Scan URL'}</button>
      </form>

      {error && <div className="card error">{error}</div>}

      {result && (
        <div className="card">
          <div className="result-header">
            <Badge status={result.prediction} />
            <span className="prob">Model confidence: {Math.round(result.probability*100)}%</span>
          </div>
          <div className="reason">
            <h3>Why was this flagged?</h3>
            {result.reasons.length ? (
              <ul>
                {result.reasons.map((r,i)=>(<li key={i}>• {r}</li>))}
              </ul>
            ) : <p>No obvious red flags found.</p>}
          </div>
          <div className="url">URL: <code>{result.url}</code></div>
        </div>
      )}

      <div className="card">
        <h3>Dashboard</h3>
        <p>Total scans: <b>{stats.total}</b></p>
        <Progress label="Phishing rate" value={stats.phishing_pct} max={100} />
        <div className="grid">
          <div className="kpi"><span>{stats.phishing}</span><small>Phishing</small></div>
          <div className="kpi"><span>{stats.legit}</span><small>Safe</small></div>
        </div>
      </div>

      <footer>Backend: <code>{import.meta.env.VITE_API_BASE || 'http://localhost:8000'}</code></footer>
    </div>
  )
}
