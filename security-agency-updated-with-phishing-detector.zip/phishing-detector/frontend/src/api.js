// Set your backend URL here (e.g., Render/Railway public URL)
export const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000';

export async function predictUrl(url) {
  const res = await fetch(`${API_BASE}/predict`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url })
  })
  if (!res.ok) throw new Error('Network error')
  return res.json()
}

export async function fetchStats() {
  const res = await fetch(`${API_BASE}/stats`)
  if (!res.ok) throw new Error('Network error')
  return res.json()
}
