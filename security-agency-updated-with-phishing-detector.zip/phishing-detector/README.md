# Phishing URL Detection with AI (Assignment 1)

This folder `phishing-detector/` contains a complete **FastAPI backend** and **React (Vite) frontend**:
- Input URL → backend ML model predicts **✅ Safe** or **❌ Phishing**
- Shows **explainability reasons** (keywords, TLDs, URL length, IP in domain, etc.)
- Simple **dashboard** with % phishing vs. safe scanned so far

## Quickstart (Local)

### 1) Backend
```bash
cd phishing-detector/backend
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```
API runs at `http://localhost:8000`

### 2) Frontend
```bash
cd phishing-detector/frontend
npm install
# Create .env and set your backend URL if needed:
# echo "VITE_API_BASE=http://localhost:8000" > .env
npm run dev
```
App runs at `http://localhost:5173`

## Deployment
- **Frontend**: Deploy `frontend` (built `dist/`) to **Vercel/Netlify**.
- **Backend**: Deploy `backend` to **Render/Railway/HuggingFace Spaces**.
  - Remember to allow CORS and set the correct public API URL in frontend `.env` as `VITE_API_BASE`.

## Bonus Points Implemented
- ✅ Explainability with reasons (heuristics)
- ✅ Visualization: dashboard shows phishing % and counters

## Notes
- For better accuracy, replace `backend/sample_dataset.csv` with a larger real dataset and retrain (the app trains the lightweight model on startup).
- All code is self-contained and ready to push to GitHub.
